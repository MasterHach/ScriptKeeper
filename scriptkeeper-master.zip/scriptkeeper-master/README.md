# Hello, my name is Alex :hand:

### IT Student

---

## ScriptKeeper

### Description

Application for keeping your scripts in a single place. You can add new scripts to general storage and mark them as
personal, so other people couldn't see them. Also, you can insert fields into expended properties fast convenient.

### Main features

- Instantaneous script search
- Green backlight and top sorting for personal scripts
- Ability to save extended properties as a file
- Deleting scripts from your storage if you don't need it anymore

### How to install

1. Download ZIP of the project
2. Run main.py in the root of project

### Requirements

'''
dearpygui~=1.9.1
pyodbc~=4.0.39
openpyxl~=3.1.2
'''