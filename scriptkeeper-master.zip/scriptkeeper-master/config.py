import os

server = "S00AZRC01DEV\SNAP01"
database = "SPIKE"
driver = "{ODBC Driver 17 for SQL Server}"
username = os.getlogin()
